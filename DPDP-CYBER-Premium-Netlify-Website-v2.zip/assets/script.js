
const toggle = document.querySelector('.menu-toggle');
const mobile = document.querySelector('.mobile-nav');
if(toggle && mobile){
  toggle.addEventListener('click',()=>mobile.classList.toggle('open'));
}

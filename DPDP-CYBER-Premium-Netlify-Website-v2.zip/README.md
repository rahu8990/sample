# DPDP CYBER — Premium Netlify Website

This is a static HTML/CSS/JS website designed for Netlify.

## Navigation
Home · About · Practice Areas (dropdown) · Careers · Blogs · Contact Us

Practice Areas:
- Data Protection & Privacy
- DPDP Compliance
- Cyber Law
- Intellectual Property Rights
- Civil & Criminal Litigation
- Technology & Digital Law

## Contact details currently shown
Phone: 9647469557
Office: E-128, E-Block, Mayur Vihar, 110091

No advocate's personal name is displayed on the site.

## Deploy
1. Extract this ZIP.
2. Log in to Netlify.
3. Create a new site / deploy manually.
4. Drag the extracted folder into the deploy area.
5. Test the temporary Netlify URL before changing the existing custom-domain site.

## Editing
- Main pages are individual .html files.
- Design is in assets/style.css.
- Mobile menu is in assets/script.js.
- Blog articles are separate HTML files.
- Contact form is configured for Netlify Forms.

## Professional-conduct design choices
The site avoids testimonials, rankings, comparative claims, guaranteed outcomes, "best" language and aggressive solicitation language. It presents practice areas and informational blogs in a restrained professional format.

Please have the final wording, contact workflow and any future promotional material checked against the professional rules applicable to advocates before publication. The Bar Council of India rules include restrictions concerning solicitation/advertising by advocates.
